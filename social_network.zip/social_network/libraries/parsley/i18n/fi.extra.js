// Validation errors messages for Parsley
import Parsley from '../parsley';

Parsley.addMessages('fi', {
  dateiso: "Sy&ouml;t&auml; oikea p&auml;iv&auml;m&auml;&auml;r&auml; (YYYY-MM-DD)."
});
