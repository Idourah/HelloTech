<?php
session_start();
require("filters/guess_filter.php");
require('config/database.php');
require('include/functions.php');
require('include/constante.php');

   if(isset($_POST['register']))
   {
     if(not_empty(['name','pseudo','email','password','password_confirm']))
     {
       $errors = [];
       extract($_POST);
       if(mb_strlen($pseudo) < 4 )
       {
         $errors[] = "le pseudo doit contenir au moins 4 caracteres";
       }
       if(!filter_var($email,FILTER_VALIDATE_EMAIL))
       {
         $errors[] = "adresse email non valide";
       }
       if(mb_strlen($password) < 8)
       {
         $errors [] ="le mot de passse trop court (Minimum 6 caracteres)";
       }
       else
       {
         if($password != $password_confirm)
         {
           $errors[] = "les deux mots de passe ne sont pas identiques";
         }
       }
       if(is_already_in_use('pseudo',$pseudo, 'user'))
       {
         $errors[] = "pseudo deja utilise";
       }
       if(is_already_in_use('email',$email, 'user'))
       {
         $errors[] = "adresse email deja utilise";
       }
       if(count($errors) == 0)
       {

         $to = $email;
         $subject = WEBSITE_NAME." -ACTIVATION DU COMPTE";
         $token = sha1($pseudo.$email.$password);

         ob_start();
         require('tamplate/emails/activation.view.php');
         $content = ob_get_clean();
         $headers = 'MIME-Version: 1.0' . "\r\n";
         $headers = "Content-type: text/html; charset=iso-8859-1" . "\r\n";

         $query = $db->prepare('INSERT INTO user (name,pseudo,email,pass)
                             VALUES(:name,:pseudo,:email,:password)');
         $query->execute([
           'name' => $name,
           'pseudo' => $pseudo,
           'email' => $email,
           'password' => sha1($password)

         ]);

         set_flash('votre compte a été crée avec succès !','success');
         header("Location:index.php");
        // mail($to,$subject,$content,$headers);

         //echo "mail d'activation envoye";

         //Envoi email d activation
         //Enregistrement de l utilisateur
         //message de bienvenu
         //redirection vers sa page de profil
       }
       else
       {
         save_data_input();
       }
     }	
     else
     {
       $errors[] = "veillez remplir tous les champs";
       save_data_input();
     }
   }
   else
   {
     clear_data_input();
   }
?>


<?php

require("views/register.view.php");
?>
