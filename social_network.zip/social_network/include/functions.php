				<?php

if(!function_exists('e'))
{
  function e($string)
  {
    if($string)
    {
      return strip_tags($string);
      return htmlspecialchars($string);
      return htmlentities($string,ENT_QUOTES,'UTF-8, false');

    }
  }
}
if(!function_exists('not_empty'))
{
  function not_empty($fields = [])
  {
    if(count($fields != 0))
    {
      foreach ($fields as $field ) {
        # code...
        if(empty($_POST[$field]) || trim($_POST[$field]) == "")
        {
          return false;
        }
      }
      return true;
    }
  }
}

if(!function_exists('is_already_in_use'))
{
  function is_already_in_use($field,$value,$table)
  {
    global $db;
    $query = $db->prepare("SELECT id FROM $table WHERE $field = ?");
    $query->execute([$value]);
    $count = $query->rowCount();
    $query->closeCursor();

    return $count;
  }
}
if(!function_exists('set_flash'))
{
  function set_flash($message,$type)
  {
       $_SESSION['notification']['message'] = $message;
       $_SESSION['notification']['type'] = $type;
  }
}
if(!function_exists('save_data_input'))
{
  function save_data_input()
  {
    foreach ($_POST as $key => $value) {
      # code...this function allows to save data into our form
      if(strpos($key,'password') === false)
      {
            $_SESSION['input'][$key] = $value;
      }

    }
  }
}
if(!function_exists('get_data'))
{
  function get_data($key)
  {
    if(!empty($_SESSION['input'][$key]))
    {
        return e($_SESSION['input'][$key]);
    }
    else
    {
      return false;
    }

  }
}

if(!function_exists('clear_data_input'))
{
  function clear_data_input()
  {
    if(isset($_SESSION['input']))
    {
      $_SESSION['input'] = [];
    }
  }
}
if(!function_exists('redirect'))
{
  function redirect($link)
  {
    header("Location:$link");
  }
}
?>
