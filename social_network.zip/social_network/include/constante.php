<?php
  define('WEBSITE_NAME','chat');
  define('WEBSITE_URL','http//:localhost/')
?>
