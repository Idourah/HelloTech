<?php
session_start();
require("filters/user_filter.php");

require("views/profile.view.php");
?>
