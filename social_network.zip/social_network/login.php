<?php
session_start();
require("filters/guess_filter.php");
require("config/database.php");
require("include/functions.php");
if(isset($_POST["login"]))
{
  if(not_empty(['identifiant','password']))
  {

    extract($_POST);

    $query = $db->prepare("SELECT id,pseudo FROM user
                         WHERE (pseudo = :identifiant or email = :identifiant)
                         AND pass = :password");

    $query->execute([
      'identifiant' => $identifiant,
      'password'  => sha1($password)
    ]);

    $userHasBeeFound = $query->rowCount();
    if($userHasBeeFound)
    {
      $user = $query->fetch(PDO::FETCH_OBJ);
      $_SESSION['user_id'] = $user->id;
      $_SESSION['pseudo'] = $user->pseudo;
      header("Location:profile.php");
    }
    else
    {
      set_flash("identifiant ou mot de passe incorecet",'danger');
      save_data_input();
    }
  }
}
require("views/login.view.php");
?>
