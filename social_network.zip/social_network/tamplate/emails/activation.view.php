<!DOCTYPE HTML>
<html>
   <head>
        <meta charset="utf-8">
   </head>

   <body>
        <h2>Activation du compte</h2>
        <p>Pour activer votre compte veillez cliquer sur le lien</p>
        <a href="<?= WEBSITE_URL.'/activation.php?p='.$pseudo.'&amp;token='.$token ?>">Activation</a>
   </body>
</html>
