<!doctype html>
<html lang="en-usa">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=width-device, initial-scale=1">
      <meta name="author"   content="Hello-Tech">
      <title>Welcome</title>
      <link rel="stylesheet" type="text/css" href="libraries/boostrap/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="asset/css/connexion.css">
      <link rel="stylesheet" type="text/css" href="asset/css/main.css">
    </head>

    <body>
      <div class="container" id="container">
         <div class="row">
            <div class="col-lg-8">

                <form data-parsley-validate id="form" method="post" >
                    <div class="form-group">
                         <input type="text"     class="form-control" value="<?=get_data('identifiant')?>" placeholder="pseudo ou email" id="email"    name="identifiant"   required="required">

                         <input type="password" class="form-control"  placeholder="mot de passe"    id="password" name="password" required="required">
                    </div>

                    <div class="checkbox">
                         <label><input type="checkbox" id="checkbox"><span id="checktxt">Se souvenir de moi</span></label>
                    </div>
                    <button type="submit" class="btn btn-default" id="submit-btn" name="login">connexion</button>
                    <a href="register.php" class="btn btn-default look" id="btn-link" >cree un compte</a><br>
                    <a href="#" id="forgot-link">mot de passe oublié</a><br><br>
                </form>
                <div id="alert">
                      <?php include('partials/_flash.php')?>
                </div>
            </div>


         </div>
      </div>
      <script type="text/javascript" src="libraries/jquery/jquery.js"></script>
      <script type="text/javascript" src="libraries/boostrap/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="libraries/parsley/parsley.min.js"></script>
      <script type="text/javascript" src="libraries/parsley/i18n/fr.js"></script>
      <script>
           window.parsleyValidator.setLocale('fr');
      </script>
    </body>

</html>
