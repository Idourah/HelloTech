<!doctype html>
<html>
   <head>
      <title>profile</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
      <link rel="stylesheet" href="asset/css/style.css">
   </head>
   <body>
      <div id="container">
         <?php include("partials/_header.php");?>
      </div>
   </body>
   <script src="libraries/jquery/jquery.js"></script>
​  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</html>
    
