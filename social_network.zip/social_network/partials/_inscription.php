<!doctype html>
<html lang="fr-FR">
   <head>
      <meta charset="utf-8">
       <title>Register</title>
       <link rel="stylesheet" type="text/css" href="asset/css/register.css">
       <link rel="stylesheet" type="text/css" href="asset/css/main.css">
       <link rel="stylesheet" type="text/css" href="libraries/boostrap/css/bootstrap.min.css">
   </head>

   <body id="corps">


     <div id="all">
            <form data-parsley-validate method="post" autocomplete='off'>
              <?php  include('partials/_errors.php');?>
              <p><span  class="glyphicon glyphicon-home"></span></p>
                <div id="first" class="form-group">
                   <input type="text"     placeholder="nom" value="<?= get_data('name')?>" class="form-control" name="name" required>
                   <input type="text"    data-parsley-minlength="4" placeholder="pseudo" value="<?= get_data('pseudo')?>" class="form-control" name="pseudo" required>
                   <input type="email"    placeholder="adresse email" value="<?= get_data('email')?>" class="form-control" name="email"  data-parsley-trigger="keypress" required>
                   <input type="password" placeholder="mot de passe"  class="form-control" name="password" id="password" required>
                   <input type="password" placeholder="confirmer le mot de passe" class="form-control" name="password_confirm" required data-parsley-equalto="#password">
                </div>
                <button type="submit"class="btn btn-default" name="register">Inscription</button>
                <a  href="index.php" class="btn btn-default" id="btn-annuler">annuler</a>
            </form>
     </div>
      <script type="text/javascript" src="libraries/jquery/jquery.js"></script>
      <script type="text/javascript" src="libraries/boostrap/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="libraries/parsley/parsley.min.js"></script>
      <script type="text/javascript" src="libraries/parsley/i18n/fr.js"></script>
    </body>
</html>
