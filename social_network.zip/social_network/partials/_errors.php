<?php
if(isset($errors) && count($errors) != 0)
  {
    echo '<div class="alert alert-warning alert-dismissible" id="alert_message">

              <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span>
              <span class="sr-only">Close</span></button>';
          foreach ($errors as $error) {
            echo $error.'<br>';
            # code...
          }
    echo '</div>';

  }

?>
