<?php
if(isset($_SESSION['notification']['message'])):?>
     <div class="alert alert-<?=$_SESSION['notification']['type']?>" id="succes_msg">
       <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span>
       <span class="sr-only">Close</span></button>
       <p><?=$_SESSION['notification']['message']?></p>

     </div>
     <style>
       #succes_msg
       {
         width:350px;
         height:50px;
         margin-left:-15px;
       }
     </style>
     <?php $_SESSION['notification'] = [];?>
<?php endif;
