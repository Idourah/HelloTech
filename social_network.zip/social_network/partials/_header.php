<!doctype html>
<html>
   <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="asset/css/style.css">
   </head>

   <body>
     <header>
        <div id="logo"> <span id="edu-ico" class="glyphicon glyphicon-education"></div>
        <nav>
          <div class="input-group" id="search">
         <input type="text" class="form-control" id="form-control "placeholder="Search">
         <div class="input-group-btn">
           <button class="btn btn-default" type="submit">
           <i class="glyphicon glyphicon-search search-icone"></i>
           </button>
         </div>
        </div>
         <ul>
            <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Home"><span id="icone"  class="glyphicon glyphicon-home"></span></span></a></li>
            <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Profil"><span id="icone"  class="glyphicon glyphicon-user"></span></a></li>
          <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Messages"><span id="icone" class="glyphicon glyphicon-envelope"></span></a></li>
          <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Notifications"><span id="icone"  class="glyphicon glyphicon-bell"></span></a></li>
          <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Gallery"><span id="icone"  class="glyphicon glyphicon-picture"></span></a></li>
         </ul>
        </nav>

           <a id="div_par" href="#" data-toggle="tooltip" data-placement="bottom" title="log-out"><span id="param" class="glyphicon glyphicon-log-out"></span></a>

     </header>
   </body>
   <script src="libraries/jquery/jquery.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</html>
