<?php
require("partials/_profile.php");
?>
