<?php
include("partials/_inscription.php");
?>
