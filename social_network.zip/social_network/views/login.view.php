<?php
include("partials/_connexion.php");
?>
